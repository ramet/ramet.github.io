#include <mpi.h>
#include <pthread.h>

#define CHECK(x,y) if (x) perror(y);

#if	defined(_AIX32_THREADS)	||	defined(CMA_INCLUDE)
#define POSIX_1003_4A_DRAFT_4
#else	/*	_AIX32_THREADS || CMA_INCLUDE	*/
#define POSIX_1003_4A_DRAFT_7
#endif	/*	_AIX32_THREADS || CMA_INCLUDE	*/

int x1 = 0;
int x2 = 0;

void *func1(void *x) {
  x1 = 1;
}

void *func2(void *x) {
  x2 = 2;
}

main (int argc, char **argv) {
  int rc,rank;
  pthread_t t1, t2;
  void *p1, *p2;

  pthread_init();

  MPI_Init(&argc, &argv);

#if	defined(POSIX_1003_4A_DRAFT_4)
  rc = pthread_create (&t1,
		       pthread_attr_default,
		       func1,
		       (pthread_addr_t)0);
  CHECK(rc,"pthread_create");
  rc = pthread_create (&t2,
		       pthread_attr_default,
		       func2,
		       (pthread_addr_t)0);
  CHECK(rc,"pthread_create");
#else	/*	!POSIX_1003_4A_DRAFT_4	*/
  {
    pthread_attr_t	pthread_attr;

    rc = pthread_attr_init(&pthread_attr);
    CHECK(rc, "pthread_attr_init");

    rc = pthread_attr_setdetachstate(&pthread_attr,
				     PTHREAD_CREATE_UNDETACHED);
    CHECK(rc, "pthread_attr_setdetachstate");
		
    rc = pthread_create(&t1,
			&pthread_attr,
			func1,
			NULL);
    CHECK(rc,"pthread_create");
    rc = pthread_create(&t2,
			&pthread_attr,
			func2,
			NULL);
    CHECK(rc,"pthread_create");

    rc = pthread_attr_destroy(&pthread_attr);
    CHECK(rc, "pthread_attr_destroy");
  }
#endif	/*	!POSIX_1003_4A_DRAFT_4	*/

  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  printf("hello %d\n", rank);

  pthread_join(t1, &p1);
  pthread_join(t2, &p2);

  printf("x(%d,%d)\n", x1, x2);

  pthread_detach(t1);
  pthread_detach(t2);

  MPI_Finalize();
}
