#include <mpi.h>
#include <pthread.h>

#define NODEBUG
#define ITER 10
#define CHECK(x,y) if (x) perror(y);

#if	defined(_AIX32_THREADS)	||	defined(CMA_INCLUDE)
#define POSIX_1003_4A_DRAFT_4
#else	/*	_AIX32_THREADS || CMA_INCLUDE	*/
#define POSIX_1003_4A_DRAFT_7
#endif	/*	_AIX32_THREADS || CMA_INCLUDE	*/

int x1[ITER];
int x2[ITER];
MPI_Status  status;
MPI_Request request;
int rank,numtasks;
pthread_mutex_t akMpiMutex;

int akMPI_Isend(void* buf, int count, MPI_Datatype datatype,
                int dest, int tag,
                MPI_Comm comm, MPI_Request *request) {
  int r;

#ifdef DEBUG
  printf("before lock Isend\n");
#endif
  pthread_mutex_lock(&akMpiMutex);
#ifdef DEBUG
  printf("after lock Isend\n");
#endif
  r = MPI_Isend(buf, count, datatype, dest, tag, comm, request);
#ifdef DEBUG
  printf("before unlock Isend\n");
#endif
  pthread_mutex_unlock(&akMpiMutex);
#ifdef DEBUG
  printf("after unlock Isend\n");
#endif
  return r;
}

int akMPI_Irecv(void* buf, int count, MPI_Datatype datatype,
                int dest, int tag,
                MPI_Comm comm, MPI_Request *request) {
  int r;

#ifdef DEBUG
  printf("before lock Irecv\n");
#endif
  pthread_mutex_lock(&akMpiMutex);
#ifdef DEBUG
  printf("after lock Irecv\n");
#endif
  r = MPI_Irecv(buf, count, datatype, dest, tag, comm, request);
#ifdef DEBUG
  printf("before unlock Irecv\n");
#endif
  pthread_mutex_unlock(&akMpiMutex);
#ifdef DEBUG
  printf("after unlock Irecv\n");
#endif
  return r;
}

int akMPI_Test(MPI_Request *request, int *flag, MPI_Status *status)
{
  int r;

#ifdef DEBUG
  printf("before lock Test\n");
#endif
  pthread_mutex_lock(&akMpiMutex);
#ifdef DEBUG
  printf("after lock Test\n");
#endif
  r = MPI_Test(request,flag,status);
#ifdef DEBUG
  printf("before unlock Test\n");
#endif
  pthread_mutex_unlock(&akMpiMutex);
#ifdef DEBUG
  printf("after unlock Test\n");
#endif
  return r;
}

void *func1(void *x) {
  int i,j,ok=0;

  for (i=0;i<ITER;i++)
    {
      printf("func1 : init send %d\n",i);
      akMPI_Isend(&(x1[i]),1,MPI_INT,!rank,rank,MPI_COMM_WORLD,&request);
      printf("func1 : Isend %d\n",i);
      ok=0;
      while(!ok)
	{
	  akMPI_Test(&request,&ok,&status);
	  printf("func1 : Test send %d\n",i);
	  pthread_yield();
	}
    }
}

void *func2(void *x) {
  int i,ok=0;

  for (i=0;i<ITER;i++)
    {
      printf("func2 : init recv %d\n",i);
      akMPI_Irecv(&(x2[i]),1,MPI_INT,!rank,!rank,MPI_COMM_WORLD,&request);
      printf("func2 : Irecv %d\n",i);
      ok=0;
      while(!ok)
	{
	  akMPI_Test(&request,&ok,&status);
	  printf("func2 : Test recv %d\n",i);
	  pthread_yield();
	}
    }
}

main (int argc, char **argv) {
  int i,rc;
  pthread_t t1, t2;
  void *p1, *p2;

  for (i=0;i<ITER;i++)
    {
      x1[i]=1;
      x2[i]=0;
    }

  pthread_init();

  MPI_Init(&argc, &argv);
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &numtasks);
  printf("hello %d\n", rank);
  MPI_Barrier(MPI_COMM_WORLD);

  pthread_mutex_init(&akMpiMutex,NULL);

#if	defined(POSIX_1003_4A_DRAFT_4)

  rc = pthread_create (&t1,
		       pthread_attr_default,
		       func1,
		       (pthread_addr_t)0);
  CHECK(rc,"pthread_create");
  rc = pthread_create (&t2,
		       pthread_attr_default,
		       func2,
		       (pthread_addr_t)0);
  CHECK(rc,"pthread_create");

#else	/*	!POSIX_1003_4A_DRAFT_4	*/

  {
    pthread_attr_t	pthread_attr;

    rc = pthread_attr_init(&pthread_attr);
    CHECK(rc, "pthread_attr_init");

    rc = pthread_attr_setdetachstate(&pthread_attr,
				     PTHREAD_CREATE_UNDETACHED);
    CHECK(rc, "pthread_attr_setdetachstate");
		
    rc = pthread_create(&t1,
			&pthread_attr,
			func1,
			NULL);
    CHECK(rc,"pthread_create");
    rc = pthread_create(&t2,
			&pthread_attr,
			func2,
			NULL);
    CHECK(rc,"pthread_create");

    rc = pthread_attr_destroy(&pthread_attr);
    CHECK(rc, "pthread_attr_destroy");
  }

#endif	/*	!POSIX_1003_4A_DRAFT_4	*/

  pthread_join(t1, &p1);
  pthread_join(t2, &p2);

  for (i=0;i<ITER;i++)
    printf("x(%d,%d)\n", x1[i], x2[i]);

  pthread_detach(t1);
  pthread_detach(t2);

  pthread_mutex_destroy(&akMpiMutex);

  MPI_Finalize();
}


