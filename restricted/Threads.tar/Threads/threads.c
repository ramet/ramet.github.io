#include <mpi.h>
#include <pthread.h>

int x1 = 0;
int x2 = 0;

void *func1(void *x) {
  x1 = 1;
}

void *func2(void *x) {
  x2 = 2;
}

main (int argc, char **argv) {
  int rank;
  pthread_t t1, t2;
  void *p1, *p2;
  
  pthread_init();
  
  MPI_Init(&argc, &argv);
  
  pthread_create(&t1, NULL, func1, NULL);
  pthread_create(&t2, NULL, func2, NULL);

  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  printf("hello %d\n", rank);

  pthread_join(t1, &p1);
  pthread_join(t2, &p2);

  printf("x(%d,%d)\n", x1, x2);

  pthread_detach(t1);
  pthread_detach(t2);

  MPI_Finalize();
}
