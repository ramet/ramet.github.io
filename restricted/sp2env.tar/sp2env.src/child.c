#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/time.h>
#include "child.h"

int start_child(char *cmd,FILE **readpipe, FILE **writepipe)
{
  int childpid,pipe1[2],pipe2[2];
  
  if ((pipe(pipe1)<0)||(pipe(pipe2)<0))
    {
      perror("pipe");
      exit(-1);
    }
  if ((childpid=vfork())<0)
    {
      perror("fork");
      exit(-1);
    }
  else if (childpid>0)
    {
      close(pipe1[0]);
      close(pipe2[1]);
      *readpipe=fdopen(pipe2[0],"r");
      *writepipe=fdopen(pipe1[1],"w");
      setlinebuf(*writepipe);
      return childpid;
    }
  else
    {
      close(pipe1[1]);
      close(pipe2[0]);
      dup2(pipe1[0],0);
      dup2(pipe2[1],1);
      close(pipe1[0]);
      close(pipe2[1]);
      if (execlp(cmd,cmd,NULL)<0)
	{
	  perror("execlp");
	  exit(-1);
	}
    }
}

      
