#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include "child.h"
#include ".dir.h"

#define NAMESIZE 20

void main(int argc,char **argv)
{
  FILE *read_from,*write_to,*file;
  char result[80];
  int nbvar,childpid;
  char *venv;

  char tab[LASTSCRIPT][NAMESIZE]=
    {"MP_EUILIB","MP_PROCS","MP_HOSTFILE","MP_RESD","MP_RMPOOL",
     "MP_TMPDIR","TMP_TRACEDIR","MP_TRACEFILE","MP_TRACELEVEL","MP_PGMMODEL",
     "MP_EUIDEVICE","MP_LABELIO","MP_RETRY","","","","","","",
     "Program","WorkDir","ResultDir","IN_DataFiles","OUT_DataFiles","LogFile"};

  if (argc!=1) 
    {
      printf("Usage : %s\n",argv[0]);
      exit(1);
    }

  childpid=start_child(WISHPATH,&read_from,&write_to);
  strcpy(result,TCLDIR);
  strcat(result,"\n");
  fprintf(write_to,result);

  for (nbvar=FIRSTPOE;nbvar<=LASTPOE;nbvar++)
    if (venv=getenv(tab[nbvar-1]))
      {
	fprintf(write_to,"set command%d %s\n",nbvar,venv);	
	free(venv);
      }
  for (nbvar=FIRSTSCRIPT;nbvar<=LASTSCRIPT;nbvar++)
    if (venv=getenv(tab[nbvar-1]))
      {
	fprintf(write_to,"set command%d %s\n",nbvar,venv);	
	free(venv);
      }
  
  while(1)
    {
      if (fgets(result,80,read_from)<=0) exit(0);
      switch (result[0])
	{
	case '.' :
	  {
	    char tmp[80];
	    char *vtmp;

	    if (!(vtmp=getenv("HOME")))
	      {
		printf("$HOME not set !!!\n");
		exit(1);
	      }
	    strcpy(tmp,vtmp);
	    strcat(tmp,"/");
	    strcat(tmp,ENVFILE);
	    if (!(file=fopen(tmp,"w")))
	      {
		printf("Can't open file %s\n",tmp);
		exit(1);
	      }
	    break;
	  }
	case ',' :
	  fclose(file);
	  break;
	case ';' :
	  system("start_poe");
	  break;
	case ':' :
	  system("start_loadl");
	  break;
	case '#' :
	  system("start_init");
	  break;
	case '$' :
	  system("start_clean");
	  break;
	case '?' :
	  system(HELPDIR);
	  break;
	default :
	  fprintf(file,"%s",result);
	}
    }
}


