#ifndef _ndw_CHILD_H
#define _ndw_CHILD_H

#include <stdio.h>
#include <sys/types.h>
#include <sys/time.h>

extern int start_child(char *cmd,FILE **readpipe,FILE **writepipe);

#endif
