#!/bin/sh -f

umask 077

export ENVFILE=$HOME/yUgDwLk

export TK_LIBRARY=/usr/local/lib/tk

if [ -f $ENVFILE ]; then
  . $ENVFILE
else
  cat > $ENVFILE <<EOF
export MP_EUILIB=us
export MP_PROCS=2
export MP_HOSTFILE=$HOME/host.list
export MP_RESD=yes
export MP_RMPOOL=1
unset MP_TMPDIR
unset MP_TRACEDIR
unset MP_TRACEFILE
unset MP_TRACELEVEL
export MP_PGMMODEL=spmd
unset MP_EUIDEVICE
export MP_LABELIO=yes
export SP_NAME=stanley
EOF
  . $ENVFILE
fi

